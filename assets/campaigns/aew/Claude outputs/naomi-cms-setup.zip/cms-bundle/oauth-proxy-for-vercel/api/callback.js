// Step 2 of the login handshake: GitHub sends the browser back here with a one-time
// `code`. This function trades that code (plus the secret, which only lives here,
// never in the browser) for a real access token, then hands it to the admin page
// via postMessage — the same handshake Decap CMS's GitHub backend expects.
module.exports = async (req, res) => {
  const clientId = process.env.OAUTH_CLIENT_ID;
  const clientSecret = process.env.OAUTH_CLIENT_SECRET;
  const { code, error, error_description } = req.query;

  if (error) {
    res.status(400).send(renderMessage('error', { error, error_description }));
    return;
  }
  if (!code) {
    res.status(400).send('Missing "code" parameter from GitHub.');
    return;
  }
  if (!clientId || !clientSecret) {
    res.status(500).send('Server is missing OAUTH_CLIENT_ID / OAUTH_CLIENT_SECRET — set them in Vercel project settings.');
    return;
  }

  try {
    const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, code }),
    });
    const tokenData = await tokenRes.json();

    if (tokenData.error) {
      res.status(400).send(renderMessage('error', tokenData));
      return;
    }

    res.setHeader('Content-Type', 'text/html');
    res.send(renderMessage('success', { token: tokenData.access_token, provider: 'github' }));
  } catch (err) {
    res.status(500).send(renderMessage('error', { error: 'exchange_failed', error_description: String(err) }));
  }
};

function renderMessage(status, payload) {
  // Decap's admin page listens for exactly this "authorization:github:<status>:<json>" format.
  const content = JSON.stringify(payload);
  return `<!doctype html><html><body>
<script>
(function() {
  function receive(e) {
    window.opener.postMessage(
      'authorization:github:${status}:${content.replace(/</g, '\\u003c')}',
      '*'
    );
    window.removeEventListener('message', receive, false);
  }
  window.addEventListener('message', receive, false);
  window.opener.postMessage('authorizing:github', '*');
})();
</script>
</body></html>`;
}
