# Setting up your private content editor (/admin)

This gives you a private page — `yoursite.com/admin` — where you log in with GitHub
and add or edit portfolio pieces (including uploading new images) through a form,
instead of touching code or the folder on your laptop. Behind the scenes it commits
straight to your GitHub repo, the same as if you'd edited the files yourself.

There are two pieces:
1. **`admin/` folder** — goes inside your actual portfolio site repo. This is the editor page itself.
2. **`oauth-proxy/` folder** (this one) — a separate, tiny piece of code that has to run
   somewhere other than GitHub Pages, because it holds a secret that lets it prove to
   GitHub "yes, this login attempt is really allowed." GitHub Pages can only serve
   static files, so this one small piece needs its own free home — Vercel.

Do the steps in this order — the URLs from each step feed into the next one.

---

## Step 1 — Deploy the OAuth proxy to Vercel

1. Go to vercel.com and sign up (free) — signing up with your GitHub account is easiest.
2. From your Vercel dashboard, choose **Add New → Project**, and import this
   `oauth-proxy` folder (upload it as its own new GitHub repo first — e.g. name it
   `naomi-cms-oauth-proxy` — then import that repo into Vercel; Vercel needs a repo
   to deploy from). Keep all the default build settings — there's nothing to configure yet.
3. Deploy it. Vercel will give you a URL like `https://naomi-cms-oauth-proxy.vercel.app`.
   **Copy this URL** — you'll need it in the next two steps.

## Step 2 — Create a GitHub OAuth App

1. On GitHub, go to **Settings → Developer settings → OAuth Apps → New OAuth App**
   (direct link: https://github.com/settings/applications/new).
2. Fill in:
   - **Application name**: anything, e.g. "Naomi Portfolio CMS"
   - **Homepage URL**: your site's URL (e.g. `https://naomischaefer.com`)
   - **Authorization callback URL**: your Vercel URL from Step 1 + `/api/callback`
     (e.g. `https://naomi-cms-oauth-proxy.vercel.app/api/callback`)
3. Click **Register application**.
4. Copy the **Client ID** shown on the app's page.
5. Click **Generate a new client secret**, and copy that too — GitHub only shows it once.

## Step 3 — Give the proxy those two values

1. Back in Vercel, open your `naomi-cms-oauth-proxy` project → **Settings → Environment Variables**.
2. Add two variables:
   - `OAUTH_CLIENT_ID` = the Client ID from Step 2
   - `OAUTH_CLIENT_SECRET` = the Client Secret from Step 2
3. Redeploy the project (Vercel → Deployments → ⋯ → Redeploy) so it picks up the new variables.

## Step 4 — Point your site's admin page at all of this

Open `admin/config.yml` (the copy that goes in your *site* repo, not this one) and fill in:

```yaml
backend:
  name: github
  repo: YOUR-GITHUB-USERNAME/YOUR-REPO-NAME     # your actual portfolio repo, e.g. naomischaefer/portfolio
  branch: main                                   # or whatever your default branch is called
  base_url: https://naomi-cms-oauth-proxy.vercel.app   # your Step 1 URL, no trailing slash
  auth_endpoint: api/auth
```

## Step 5 — Add the editor to your site

Copy the `admin/` folder (with your filled-in `config.yml`) into the root of your
portfolio site repo, so it sits next to `index.html`. Commit and push it up normally —
this part is just two small files, nothing that touches your design or existing content.

## Step 6 — Try it

Visit `https://yoursite.com/admin/`, click **Login with GitHub**, and approve access.
You should see "All Projects" listed — try opening one existing entry first (don't
need to change anything) just to see the form and confirm it's reading your real data.

Because `publish_mode: editorial_workflow` is on in the config, hitting **Save** opens
a draft rather than publishing immediately — you'll see a status column (Draft /
In Review / Ready) and a separate **Publish** button once you're happy with it. Nothing
goes live on your actual site until you publish it.

---

### If something doesn't work

- **"Login with GitHub" does nothing / errors immediately** — double check the callback
  URL in the GitHub OAuth App *exactly* matches `<your-vercel-url>/api/callback`
  (https, no trailing slash, correct spelling).
- **Login redirects back but the page just spins** — check Vercel's function logs
  (Project → Deployments → your deployment → Functions) for the callback function;
  the error message there usually says exactly what's missing.
- **You see your projects but images don't preview** — this just means an image's
  path doesn't resolve from where the CMS expects; it doesn't affect the live site.

This proxy only ever sees a temporary login code and exchanges it for a token — it
doesn't store anything, log your content, or need to run except during that one
login moment.
